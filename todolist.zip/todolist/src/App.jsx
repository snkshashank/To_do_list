import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addTodo, toggleTodo, removeTodo, editTodo } from './features/todoSlice';
import './App.css';

function App() {
  const [newTodo, setNewTodo] = useState('');
  const [editingTodo, setEditingTodo] = useState(null);
  const [editingText, setEditingText] = useState('');
  const [selectedTodos, setSelectedTodos] = useState([]);
  const todos = useSelector((state) => state.todos);
  const dispatch = useDispatch();

  const handleAddTodo = () => {
    if (newTodo.trim() !== '') {
      dispatch(addTodo(newTodo));
      setNewTodo('');
    }
  };

  const handleEditTodo = (todo) => {
    setEditingTodo(todo.id);
    setEditingText(todo.text);
  };

  const handleSaveEdit = (id) => {
    if (editingText.trim() !== '') {
      dispatch(
        editTodo({
          id,
          text: editingText,
        })
      );
      setEditingTodo(null);
      setEditingText('');
    }
  };

  const handleSelectAll = () => {
    setSelectedTodos(todos.map((todo) => todo.id)); // Select all todos
  };

  const handleSelectTodo = (id) => {
    setSelectedTodos((prev) =>
      prev.includes(id) ? prev.filter((todoId) => todoId !== id) : [...prev, id]
    );
  };

  const handleDeleteSelected = () => {
    selectedTodos.forEach((id) => dispatch(removeTodo(id)));
    setSelectedTodos([]);
  };

  return (
    <div className="container">
      <h1 style={{ fontWeight: 'bolder', fontFamily: 'cursive', fontSize: '38px' }}>Todo List</h1>
      <div className="input-group">
        <input
          type="text"
          placeholder="Add new item"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
        />
        <button onClick={handleAddTodo}>+</button>
      </div>
      <div className="select-all-group">
        <button onClick={handleSelectAll}>Select All</button>
        <button
          onClick={handleDeleteSelected}
          disabled={selectedTodos.length === 0}
        >
          Delete Selected
        </button>
      </div>
      <ul className="list-btn">
        {todos.map((todo) => (
          <li key={todo.id} className={todo.completed ? 'completed' : ''}>
            <input
              type="checkbox"
              checked={selectedTodos.includes(todo.id)}
              onChange={() => handleSelectTodo(todo.id)}
            />
            {editingTodo === todo.id ? (
              <>
                <input
                  type="text"
                  value={editingText}
                  onChange={(e) => setEditingText(e.target.value)}
                />
                <button onClick={() => handleSaveEdit(todo.id)}>Save</button>
              </>
            ) : (
              <>
                {todo.text}
                <button className="edit-btn" onClick={() => handleEditTodo(todo)}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    className="bi bi-pencil"
                    viewBox="0 0 16 16"
                  >
                    <path d="M12.146 0.646a.5.5 0 0 1 .708 0L15.5 3.293a.5.5 0 0 1 0 .707L4.854 14.646a.5.5 0 0 1-.168.11l-4 1a.5.5 0 0 1-.632-.633l1-4a.5.5 0 0 1 .11-.167L12.146.646zm-.5 2.707L2 13.293V14h.707l9.646-9.646-1.707-1.707z" />
                  </svg>
                </button>
              </>
            )}
            <button className="remove-btn" onClick={() => dispatch(removeTodo(todo.id))}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-trash"
                viewBox="0 0 16 16"
              >
                <path d="M5.5 5.5A.5.5 0 0 1 6 5h4a.5.5 0 0 1 .5.5V12a.5.5 0 0 1-.5.5H6a.5.5 0 0 1-.5-.5V5.5zm7-3A.5.5 0 0 1 13 3v1h1a.5.5 0 0 1 .5.5v1.5a.5.5 0 0 1-.5.5h-1v7a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-7H1.5a.5.5 0 0 1-.5-.5V4.5A.5.5 0 0 1 1.5 4H3V3a.5.5 0 0 1 .5-.5h9zm-2.5 4.5h-5v6h5v-6zM4.5 3h7V4H4.5V3z" />
              </svg>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
